package com.schedulemaster.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddModule {
	private String name;
}
