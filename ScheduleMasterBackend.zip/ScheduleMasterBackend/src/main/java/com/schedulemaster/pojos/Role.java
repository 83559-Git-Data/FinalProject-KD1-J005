package com.schedulemaster.pojos;

public enum Role {
	ROLE_ADMIN,ROLE_FACULTY,ROLE_STUDENT
}
