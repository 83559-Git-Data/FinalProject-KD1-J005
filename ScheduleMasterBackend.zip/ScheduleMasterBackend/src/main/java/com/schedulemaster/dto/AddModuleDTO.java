package com.schedulemaster.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddModuleDTO {
	private String name;
	private int hours;
}
