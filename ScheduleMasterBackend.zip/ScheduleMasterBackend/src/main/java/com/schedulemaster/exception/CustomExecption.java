package com.schedulemaster.exception;

public class CustomExecption {

}
